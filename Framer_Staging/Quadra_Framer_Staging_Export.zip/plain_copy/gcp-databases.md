# Modernise the data estate around the workload

Legacy licensing, scaling constraints and routine administration can consume attention needed elsewhere. Quadra assesses database options on Google Cloud and plans migration, optimisation and ongoing management together.

## Assess compatibility before selecting a target

Inventory databases, dependencies and performance requirements. Compare managed-service options with application compatibility, availability, recovery, migration effort and licensing implications. Moving to a new engine may require schema and code changes.

## Choose the right database services

- Cloud SQL: managed MySQL, PostgreSQL and SQL Server for suitable relational workloads.

- AlloyDB for PostgreSQL: assess demanding transactional and analytical requirements and relevant AI or vector use cases.

- Spanner: evaluate distributed application requirements against the platform’s data and architecture model.

- Heterogeneous migration: consider Oracle or SQL Server transitions to open-source engines with explicit conversion work.

- Other data patterns: evaluate Bigtable, Firestore and Memorystore where workload characteristics justify them.

## Migrate with validation and recovery in view

Use suitable Database Migration Service capabilities and runbooks for the supported migration path. Plan interruption windows around source and target constraints. Validate data integrity, database performance and application behaviour before acceptance, with the recovery design in view.

## Operate for sustained performance

Design replicas, high availability, failover, backup and disaster recovery to fit the requirement. Tune performance after migration and connect monitoring and support through Max-IT. Compare cost and operational changes with the existing baseline to guide the next optimisation decisions.

Book a Google Cloud database assessment

## Connected expertise

- Google Cloud

- Modernize Your Foundation

- Transform with AI & Data

- Google Cloud Data & Analytics

- Google Cloud Application Modernisation

- Google Cloud Managed Services — Max-IT
