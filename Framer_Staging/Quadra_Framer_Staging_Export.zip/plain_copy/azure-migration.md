# Move with the foundation to grow

A successful migration makes the estate easier to govern, secure and operate. Quadra starts with dependencies and the target operating model, then selects the right Azure treatment for each workload.

## Assess before moving

Inventory infrastructure, applications, databases, licensing, performance, security and recovery needs. Group workloads into migration waves by dependency and business risk; agree validation, cutover and rollback criteria before execution.

## Establish the landing zone

Design or remediate management groups, subscriptions, identity, network connectivity, policy, logging, backup and recovery. Cloud Adoption Framework principles shape guardrails and operational readiness rather than treating the landing zone as an isolated deployment.

## Modernise the estate

- Move Windows, Linux, SAP and VMware workloads from on-premises, AWS or Google Cloud to Azure.

- Assess SQL Server compatibility and select Azure SQL Database, Managed Instance or SQL on Azure VMs; consider PostgreSQL, MySQL and Cosmos DB where appropriate.

- Support Azure Virtual Desktop, Azure Files and Azure NetApp Files, with Azure Arc for hybrid management.

- Design connectivity and application access using ExpressRoute, Virtual WAN, Front Door, Application Gateway and WAF.

## Validate, optimise and hand over

Protect data integrity through validation and planned recovery steps. Tune availability, performance and cost after cutover, and transition monitoring, backup, disaster recovery and operating runbooks into the agreed support model. Well-Architected and FinOps reviews identify the next improvements. Downtime windows and migration methods depend on workload constraints and the agreed sequence.

Start an Azure migration assessment

## Connected expertise

- Microsoft Azure

- Modernize Your Foundation

- Azure Application Innovation

- Azure Managed Services

- IntelliCloud Hybrid Integration
